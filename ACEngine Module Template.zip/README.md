# ACEngine project

This is the main project of the engine -- all modules and other code is combined here.