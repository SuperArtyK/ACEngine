
/** @file NAME/include/NAME.hpp
 *  This file contains the [stuff]
 *
 *  Should not cause everything to break :)
 */

#pragma once

#ifndef ENGINE_NAME_HPP
#define ENGINE_NAME_HPP

#include "include/AEModuleBase.hpp"
#include "include/AETypedefs.hpp"
#include "include/AEUtils.hpp"


#endif // !ENGINE_NAME_HPP
