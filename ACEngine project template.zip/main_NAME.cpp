#include <iostream>
#include "NAME.hpp"
using std::cout;
using std::cin;

int main() {

	cout << "Hello World! \n";

	return 0;
}
